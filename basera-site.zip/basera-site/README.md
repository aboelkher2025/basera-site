# Basera (بصيرة) — website

Corporate training, OD consulting and learning platform for companies in Saudi Arabia.

## What's here
- `index.html` — public site (EN/AR, course search, certificate check, AI career coach). No build step.
- `app.html` — the portal: sign in / sign up, learner course player with quizzes and certificates, company admin panel (team, assignments, reports), Basera admin control panel (users, companies, courses and lessons, enrolments, leads, certificates, reports).
- `.github/workflows/deploy.yml` — publishes to GitHub Pages on every push to `main`.

## Run locally
Open `index.html` in a browser, or:
```
python3 -m http.server 8080
```

## Deploy
1. Push to `main`.
2. In the repo: Settings → Pages → Source: **GitHub Actions**.
3. The Actions tab shows the deploy; the URL is `https://<user>.github.io/<repo>/`.

## Backend (Supabase project `basera`, eu-central-1)
- Auth: Supabase email/password. The first account created becomes `admin`; everyone else is `learner`. Roles: `admin`, `client_admin`, `learner`, `partner` — change them in the portal under Users.
- Tables: `organizations` (join codes), `profiles`, `courses`, `lessons`, `enrollments`, `lesson_progress`, `certificates`, `leads`, `coach_logs`. Row-level security on all of them; helper functions `my_role()` / `my_org()`.
- Automation: completing every lesson sets the enrolment to completed and issues a certificate (`BSR-YYYY-NNNNN`). Quiz pass mark is 67%.
- Set Authentication → URL Configuration → Site URL to the Pages URL so confirmation and reset links land on `app.html`.
- Edge Function `career-coach`: holds the Anthropic key server-side, answers from the live catalogue, logs each exchange.
- Required secret: `ANTHROPIC_API_KEY` (Dashboard → Edge Functions → Secrets). Without it the site falls back to keyword matching.
- The anon key in `index.html` is public by design; row-level security protects the data.

## Before going live
- Replace `hello@basera.sa` and the phone number in the contact section.
- Add real courses to `courses` and real certificates to `certificates`; the demo code `BSR-2026-00417` can be deleted.

## Custom domain
Add a `CNAME` file containing the domain, then point DNS at GitHub Pages.
